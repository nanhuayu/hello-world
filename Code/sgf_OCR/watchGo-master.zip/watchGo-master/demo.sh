#!/bin/sh

python2 -c 'import watchGo; watchGo.watchBoard()'

